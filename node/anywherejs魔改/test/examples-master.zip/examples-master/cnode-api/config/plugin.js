'use strict';

exports.validate = {
  enable: true,
  package: 'egg-validate',
};
