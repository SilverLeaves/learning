'use strict';

exports.keys = 'my super cool keys';
