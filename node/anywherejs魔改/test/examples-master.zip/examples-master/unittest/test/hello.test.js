'use strict';

const assert = require('assert');

describe('test/hello.test.js', () => {
  it('should work', () => {
    assert(Date.now() > 0);
  });
});
