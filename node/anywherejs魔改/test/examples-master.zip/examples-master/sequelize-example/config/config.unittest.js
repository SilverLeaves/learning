'use strict';

exports.sequelize = {
  dialect: 'postgres',
  database: 'example-unittest',
  host: 'localhost',
  port: '5432',
  username: 'postgres',
  password: '',
};
