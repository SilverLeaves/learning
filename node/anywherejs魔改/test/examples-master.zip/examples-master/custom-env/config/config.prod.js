'use strict';

module.exports = {
  keys: 'prod keys',
};
