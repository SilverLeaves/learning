'use strict';

module.exports = {
  keys: 'default keys',
};
