See [cnode-api](https://github.com/eggjs/examples/tree/master/hackernews)
