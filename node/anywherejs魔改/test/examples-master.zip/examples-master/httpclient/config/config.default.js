'use strict';

exports.security = {
  csrf: false,
};
