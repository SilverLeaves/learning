'use strict';

exports.keys = 'my keys';
