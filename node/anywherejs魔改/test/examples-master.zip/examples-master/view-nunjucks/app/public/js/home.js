console.log('hello egg view');
