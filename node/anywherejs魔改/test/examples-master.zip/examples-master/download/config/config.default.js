'use strict';

exports.keys = 'my secret keys';
