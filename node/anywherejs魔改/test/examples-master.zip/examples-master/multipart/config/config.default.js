'use strict';

exports.keys = 'my keys';

exports.view = {
  defaultViewEngine: 'nunjucks',
};
